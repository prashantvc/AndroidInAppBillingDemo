package com.xamarin.InAppBillingLibrary;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.android.vending.billing.IInAppBillingService;

/**
 * Created with IntelliJ IDEA.
 * User: Prashant Cholachagudda
 * Date: 21/06/13
 * Time: 12:40 PM
 */
public class InAppBillingService {

    public final String InApp = "inapp";
    public final String Subscription = "subs";
    ServiceConnection mServiceConn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mService = IInAppBillingService.Stub.asInterface(service);
            try {
                int supported = mService.isBillingSupported(API_VERSION, packageName, InApp);
                if (supported != 0) {
                    setIsSubscriptionSupported(false);
                }

                supported = mService.isBillingSupported(API_VERSION, packageName, Subscription);
                if (supported == 0) {
                    setIsSubscriptionSupported(true);
                }

            } catch (RemoteException e) {
                //TODO: Assign to property
                isInAppBillingSupported = false;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mService = null;
        }
    };
    private IInAppBillingService mService;
    private int API_VERSION = 3;
    private String packageName;
    private Context context;
    private boolean isSubscriptionSupported = false;
    private boolean isInAppBillingSupported = true;

    public InAppBillingService(Context context) {
        this.context = context;
        this.packageName = this.context.getPackageName();

        context.bindService(new
                Intent("com.android.vending.billing.InAppBillingService.BIND"),
                mServiceConn, Context.BIND_AUTO_CREATE);
    }

    public void Unbind() {
        if (mServiceConn != null) {
            context.unbindService(mServiceConn);
        }
    }

    public boolean getIsSubscriptionSupported() {
        return isSubscriptionSupported;
    }

    private void setIsSubscriptionSupported(boolean value) {
        isSubscriptionSupported = value;
    }

    public boolean getIsInAppBillingSupported() {
        return isInAppBillingSupported;
    }
}
