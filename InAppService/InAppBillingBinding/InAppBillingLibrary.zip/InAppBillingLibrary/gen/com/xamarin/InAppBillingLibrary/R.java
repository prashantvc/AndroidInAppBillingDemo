/*___Generated_by_IDEA___*/

package com.xamarin.InAppBillingLibrary;

/* This stub is for using by IDE only. It is NOT the R class actually packed into APK */
public final class R {
}